package com.endes.main;

import com.endes.model.Banco;
import com.endes.model.Cliente;
import com.endes.model.CuentaBancaria;

public class Main {
	 public static void main(String[] args) throws Exception {
		
			        // Crear cuentas
			        CuentaBancaria cuenta1 = new CuentaBancaria("12345", 1000);
			        CuentaBancaria cuenta2 = new CuentaBancaria("67890", 500);

			        // Crear clientes
			        Cliente cliente1 = new Cliente("Juan", cuenta1);
			        Cliente cliente2 = new Cliente("Ana", cuenta2);

			        // Crear banco y agregar clientes
			        Banco banco = new Banco();
			        banco.agregarCliente(cliente1);
			        banco.agregarCliente(cliente2);

			        // Realizar una transacción
			        banco.realizarTransaccion(cliente1, cuenta2, 200);

			        // Consultar saldos
			        System.out.println("Saldo de Juan: " + cuenta1.getSaldo());
			        System.out.println("Saldo de Ana: " + cuenta2.getSaldo());
			    }
}
