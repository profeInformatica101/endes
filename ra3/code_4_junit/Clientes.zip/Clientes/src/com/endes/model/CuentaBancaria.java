package com.endes.model;

public class CuentaBancaria {
    private String numeroCuenta;
    private double saldo;

    public CuentaBancaria(String numeroCuenta, double saldoInicial) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldoInicial;
    }

    public void depositar(double cantidad) throws Exception {
        if (cantidad > 0) {
            saldo += cantidad;
        }else 
        	throw new Exception("Debe ser una cantidad mayor que 0");
    }

    public boolean retirar(double cantidad) {
        if (cantidad > 0 && saldo >= cantidad) {
            saldo -= cantidad;
            return true;
        }
        return false;
    }

    public double getSaldo() {
        return saldo;
    }
    
    
    public String getNumeroCuenta() {
    	return numeroCuenta;
    }
    
}