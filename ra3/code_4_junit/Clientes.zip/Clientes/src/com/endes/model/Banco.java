package com.endes.model;

import java.util.ArrayList;
import java.util.List;

public class Banco {
    private List<Cliente> clientes;

    public Banco() {
        clientes = new ArrayList<>();
    }

    public void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public void realizarTransaccion(Cliente cliente, CuentaBancaria cuentaDestino, double cantidad) throws Exception {
        if (!clientes.contains(cliente)) {
            System.out.println("El cliente no pertenece al banco.");
            return;
        }

        CuentaBancaria cuentaOrigen = cliente.getCuenta();
        if (!cliente.tieneCuenta(cuentaOrigen)) {
            System.out.println("La cuenta de origen no pertenece al cliente.");
            return;
        }

        if (cuentaOrigen.getSaldo() < cantidad) {
            System.out.println("Fondos insuficientes en la cuenta de origen.");
            return;
        }

        cuentaOrigen.retirar(cantidad);
        cuentaDestino.depositar(cantidad);
        System.out.println("Transacción exitosa.");
    }
}