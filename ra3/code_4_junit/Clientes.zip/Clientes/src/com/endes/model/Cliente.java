package com.endes.model;
public class Cliente {
    private String nombre;
    private CuentaBancaria cuenta;

    public Cliente(String nombre, CuentaBancaria cuenta) {
        this.nombre = nombre;
        this.cuenta = cuenta;
    }

    public boolean retirar(double cantidad) {
        return cuenta.retirar(cantidad);
    }

    public double consultarSaldo() {
        return cuenta.getSaldo();
    }
    public String getNombre(){
    	return this.nombre;
    }

	public boolean tieneCuenta(CuentaBancaria cuentaOrigen) {
		return cuenta.equals(cuentaOrigen);
	}

	public CuentaBancaria getCuenta() {
		
		return this.cuenta;
	}
    
}
